// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
#pragma once

#pragma warning(disable : 4996)   //depricated functions
#pragma warning(disable : 4793)   //native code generation


// TODO: reference additional headers your program requires here

#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <mm3dnow.h>      //mmx routines
#include <vcclr.h>

