using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WED
{
    public partial class Splash : System.Windows.Forms.Form
    {
        public Splash()
        {
            InitializeComponent();
        }
    }
}